#!/usr/bin/env python3
"""
NetRecon v3.0 — Advanced Network Intelligence & Security Suite
Modules: Port Scanner · Packet Sniffer · Web Vuln Scanner · Network Recon
         Threat Detector · IDS · Spyware Detector · Ransomware Detector
         Phishing Detector · DDoS Detector · Network Monitor

For authorized security testing only.
"""

import argparse
import sys
import asyncio
from rich.console import Console
from rich.panel import Panel

from core.banner import print_banner
from tools.port_scanner import PortScanner
from tools.packet_sniffer import PacketSniffer
from tools.vuln_scanner import WebVulnScanner
from tools.network_recon import NetworkRecon
from tools.threat_detector import ThreatDetector
from tools.ids import IntrusionDetectionSystem
from tools.spyware_detector import SpywareDetector
from tools.ransomware_detector import RansomwareDetector
from tools.phishing_detector import PhishingDetector
from tools.ddos_detector import DDoSDetector
from tools.network_monitor import NetworkMonitor
from utils.logger import setup_logger
from utils.report import ReportGenerator

console = Console()
logger = setup_logger()


def parse_args():
    parser = argparse.ArgumentParser(
        description="NetRecon v3.0 — Advanced Network Intelligence & Security Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
MODULES:
  --scan-ports       Port scanner (TCP/UDP/SYN/FIN + banner/OS detection)
  --sniff            Packet sniffer with deep inspection
  --vuln-scan        Web vulnerability scanner (SQLi/XSS/LFI/SSL/headers)
  --recon            Network reconnaissance (DNS/WHOIS/ARP/traceroute)
  --detect-threats   Threat detection engine
  --ids              Intrusion Detection System (50+ signatures)
  --detect-spyware   Spyware, RAT & stalkerware detection
  --detect-ransom    Ransomware detection (C2, lateral movement, staging)
  --detect-phishing  Phishing & typosquatting detection
  --detect-ddos      DDoS detection (SYN/UDP/amplification/HTTP flood)
  --monitor          Real-time network monitor and traffic analysis dashboard
  --full-audit       Run all modules in sequence

EXAMPLES:
  python main.py --scan-ports 192.168.1.1 -p 1-1024 --banner
  python main.py --ids --interface eth0 --duration 120
  python main.py --detect-ransom --interface eth0
  python main.py --detect-phishing --interface eth0
  python main.py --detect-ddos --interface eth0 --duration 60
  python main.py --monitor --interface eth0 --duration 300
  python main.py --full-audit 192.168.1.1 -o report.html --format html

LEGAL: Use only on systems you own or have explicit written permission to test.
        """
    )

    parser.add_argument("target", nargs="?", help="Target IP, hostname, URL, or CIDR range")

    # Original modules
    parser.add_argument("--scan-ports", action="store_true")
    parser.add_argument("--sniff", metavar="INTERFACE", help="Capture packets on interface")
    parser.add_argument("--vuln-scan", action="store_true")
    parser.add_argument("--recon", action="store_true")
    parser.add_argument("--detect-threats", action="store_true")
    parser.add_argument("--full-audit", action="store_true")

    # New modules
    parser.add_argument("--ids", action="store_true", help="Intrusion Detection System")
    parser.add_argument("--detect-spyware", action="store_true", help="Spyware & RAT detection")
    parser.add_argument("--detect-ransom", action="store_true", help="Ransomware detection")
    parser.add_argument("--detect-phishing", action="store_true", help="Phishing detection")
    parser.add_argument("--detect-ddos", action="store_true", help="DDoS detection")
    parser.add_argument("--monitor", action="store_true", help="Network monitor & analysis")

    # Port scanner options
    parser.add_argument("-p", "--ports", default="1-1024")
    parser.add_argument("--scan-type", choices=["tcp", "udp", "syn", "fin"], default="tcp")
    parser.add_argument("--threads", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=1.0)
    parser.add_argument("--banner", action="store_true")
    parser.add_argument("--os-detect", action="store_true")

    # Capture options
    parser.add_argument("--duration", type=int, default=60, help="Capture duration (seconds)")
    parser.add_argument("--filter", metavar="BPF", help="BPF filter string")
    parser.add_argument("--pcap", metavar="FILE", help="Save pcap to file")
    parser.add_argument("--analyze", action="store_true")

    # Web vuln options
    parser.add_argument("--crawl-depth", type=int, default=2)
    parser.add_argument("--sqli", action="store_true")
    parser.add_argument("--xss", action="store_true")
    parser.add_argument("--lfi", action="store_true")
    parser.add_argument("--headers", action="store_true")
    parser.add_argument("--ssl", action="store_true")
    parser.add_argument("--all-vulns", action="store_true")

    # Recon options
    parser.add_argument("--dns", action="store_true")
    parser.add_argument("--whois", action="store_true")
    parser.add_argument("--traceroute", action="store_true")
    parser.add_argument("--arp-scan", action="store_true")

    # IDS options
    parser.add_argument("--rules", metavar="FILE", help="Custom IDS rules file (JSON/YAML)")

    # Common detection options
    parser.add_argument("--interface", metavar="IFACE", default="eth0")
    parser.add_argument("--alert-level",
                        choices=["info", "low", "medium", "high", "critical"],
                        default="medium")
    parser.add_argument("--block", action="store_true", help="Auto-block via iptables (root req.)")

    # Monitor options
    parser.add_argument("--baseline", type=int, default=300)
    parser.add_argument("--top-n", type=int, default=10)

    # Output options
    parser.add_argument("--output", "-o", metavar="FILE")
    parser.add_argument("--format", choices=["txt", "json", "html", "csv"], default="txt")
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--quiet", "-q", action="store_true")

    return parser.parse_args()


async def run_full_audit(args, report: ReportGenerator):
    console.print("\n[bold cyan]Full Security Audit — All Modules[/bold cyan]\n")
    phases = [
        ("1/8", "Port Scanning",             lambda: _run_port_scan(args, report)),
        ("2/8", "Network Reconnaissance",    lambda: _run_recon(args, report)),
        ("3/8", "Web Vulnerability Scan",    lambda: _run_vuln_scan(args, report)),
        ("4/8", "Packet Capture",            lambda: _run_sniffer(args, report)),
        ("5/8", "Intrusion Detection",       lambda: _run_ids(args, report)),
        ("6/8", "Spyware Detection",         lambda: _run_spyware(args, report)),
        ("7/8", "Ransomware Detection",      lambda: _run_ransomware(args, report)),
        ("8/8", "Threat Assessment",         lambda: _run_threats(args, report)),
    ]
    for num, name, fn in phases:
        console.print(Panel(f"[bold]Phase {num}: {name}[/bold]", border_style="cyan", padding=(0,2)))
        await fn()
        console.print()


async def _run_port_scan(args, report):
    s = PortScanner(args.target, args)
    await s.run()
    report.add_section("Port Scan", s.results)

async def _run_recon(args, report):
    r = NetworkRecon(args.target, args)
    await r.run()
    report.add_section("Network Recon", r.results)

async def _run_vuln_scan(args, report):
    v = WebVulnScanner(args.target, args)
    await v.run()
    report.add_section("Web Vulnerabilities", v.results)

async def _run_sniffer(args, report):
    iface = args.sniff or args.interface
    s = PacketSniffer(iface, args)
    await s.run()
    report.add_section("Packet Capture", s.results)

async def _run_threats(args, report):
    t = ThreatDetector(args)
    await t.run_assessment(report.all_results())
    report.add_section("Threat Assessment", t.results)

async def _run_ids(args, report):
    ids = IntrusionDetectionSystem(args)
    await ids.run()
    report.add_section("IDS Alerts", ids.results)

async def _run_spyware(args, report):
    s = SpywareDetector(args)
    await s.run()
    report.add_section("Spyware Detection", s.results)

async def _run_ransomware(args, report):
    r = RansomwareDetector(args)
    await r.run()
    report.add_section("Ransomware Detection", r.results)

async def _run_phishing(args, report):
    p = PhishingDetector(args)
    await p.run()
    report.add_section("Phishing Detection", p.results)

async def _run_ddos(args, report):
    d = DDoSDetector(args)
    await d.run()
    report.add_section("DDoS Detection", d.results)

async def _run_monitor(args, report):
    m = NetworkMonitor(args)
    await m.run()
    report.add_section("Network Monitor", m.results)


async def main():
    args = parse_args()

    if not args.quiet:
        print_banner()

    report = ReportGenerator()

    try:
        if args.full_audit:
            if not args.target:
                console.print("[red]Error:[/red] Target required for full audit.")
                sys.exit(1)
            await run_full_audit(args, report)

        elif args.scan_ports:
            if not args.target:
                console.print("[red]Error:[/red] Target required.")
                sys.exit(1)
            await _run_port_scan(args, report)

        elif args.sniff:
            await _run_sniffer(args, report)

        elif args.vuln_scan:
            if not args.target:
                console.print("[red]Error:[/red] Target URL required.")
                sys.exit(1)
            await _run_vuln_scan(args, report)

        elif args.recon:
            if not args.target:
                console.print("[red]Error:[/red] Target required.")
                sys.exit(1)
            await _run_recon(args, report)

        elif args.detect_threats:
            d = ThreatDetector(args)
            await d.run_live()
            report.add_section("Threat Detection", d.results)

        elif args.ids:
            await _run_ids(args, report)

        elif args.detect_spyware:
            await _run_spyware(args, report)

        elif args.detect_ransom:
            await _run_ransomware(args, report)

        elif args.detect_phishing:
            await _run_phishing(args, report)

        elif args.detect_ddos:
            await _run_ddos(args, report)

        elif args.monitor:
            await _run_monitor(args, report)

        else:
            console.print(
                "[yellow]No module selected.[/yellow] Use [cyan]--help[/cyan] for options.\n"
                "Example: [dim]python main.py --monitor --interface eth0[/dim]"
            )
            sys.exit(0)

        if args.output and report.has_data():
            report.save(args.output, fmt=args.format)
            console.print(f"\n[green]✓ Report saved:[/green] {args.output}")

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠ Interrupted.[/yellow]")
        if report.has_data() and args.output:
            report.save(args.output, fmt=args.format)
    except PermissionError:
        console.print("[red]✗ Permission denied.[/red] Try running with [cyan]sudo[/cyan].")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=args.verbose)
        console.print(f"[red]✗ Error: {e}[/red]")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
