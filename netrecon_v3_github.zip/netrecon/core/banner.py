"""
NetRecon Banner and startup display.
"""

from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich import box
import platform
import datetime

console = Console()

BANNER = r"""
 ███╗   ██╗███████╗████████╗██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗
 ████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║
 ██╔██╗ ██║█████╗     ██║   ██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║
 ██║╚██╗██║██╔══╝     ██║   ██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║
 ██║ ╚████║███████╗   ██║   ██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║
 ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝
"""

TAGLINE = "Advanced Network Intelligence & Security Suite"
VERSION = "3.0.0"
MODULES = [
    ("Port Scanner",       "TCP/UDP/SYN scan, OS detection, banner grabbing"),
    ("Packet Sniffer",     "Deep packet inspection & protocol analysis"),
    ("Web Vuln Scanner",   "SQLi, XSS, LFI, SSRF, header & SSL auditing"),
    ("Network Recon",      "DNS enum, WHOIS, ARP scan, traceroute mapping"),
    ("Threat Detector",    "Real-time anomaly detection & threat intelligence"),
    ("IDS",                "50+ attack signatures — exploits, scans, C2, brute force"),
    ("Spyware Detector",   "RAT, stalkerware, keylogger & beacon detection"),
    ("Ransomware Detector","C2, lateral movement, staging & exfil detection"),
    ("Phishing Detector",  "Typosquatting, homograph, credential harvest detection"),
    ("DDoS Detector",      "SYN/UDP/ICMP flood, amplification, Slowloris, botnet"),
    ("Network Monitor",    "Real-time flow analysis, protocol breakdown, anomalies"),
]


def print_banner():
    # ASCII art in cyan gradient
    banner_text = Text(BANNER, style="bold cyan")
    console.print(banner_text)

    # Tagline
    console.print(f"  [bold white]{TAGLINE}[/bold white]  [dim]v{VERSION}[/dim]\n")

    # Module list
    module_lines = []
    icons = ["⬡", "◈", "⬡", "◈", "⬡"]
    for i, (name, desc) in enumerate(MODULES):
        icon = icons[i % len(icons)]
        module_lines.append(f"  [cyan]{icon}[/cyan] [bold white]{name:<22}[/bold white] [dim]{desc}[/dim]")

    modules_str = "\n".join(module_lines)

    info_panel = Panel(
        f"{modules_str}\n\n"
        f"  [dim]Platform:[/dim] [white]{platform.system()} {platform.release()}[/white]  "
        f"[dim]Python:[/dim] [white]{platform.python_version()}[/white]  "
        f"[dim]Date:[/dim] [white]{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}[/white]",
        title="[bold cyan]MODULES[/bold cyan]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(0, 1),
    )
    console.print(info_panel)

    # Legal notice
    console.print(
        "\n  [bold red]⚠  LEGAL NOTICE:[/bold red] [dim]This tool is for authorized security testing ONLY.\n"
        "  Unauthorized scanning is illegal. Use only on systems you own or have\n"
        "  explicit written permission to test. The authors assume no liability.[/dim]\n"
    )
